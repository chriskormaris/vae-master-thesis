from __init__ import *

import matplotlib.pyplot as plt
import numpy as np
import time
import sys
import os

os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'  # hide tensorflow warnings

__author__ = 'c.kormaris'

missing_value = 0.5

#####

# MAIN #

output_images_dir = './browse_dataset_recommendation_system_output_images'
dataset_dir = sys.argv[6]
dataset_labels_dir = sys.argv[7]

if not os.path.exists(output_images_dir):
        os.makedirs(output_images_dir)

X = get_browse_dataset.get_browse_dataset(dataset_dir)
y = get_browse_dataset.get_browse_dataset_labels(dataset_labels_dir)

# random shuffle the data
np.random.seed(0)
s = np.random.permutation(X.shape[0])
X = X[s, :]
y = y[s]

#####

# construct data with missing values
X_missing, X, _ = Utilities.construct_missing_data(X, y, structured_or_random=sys.argv[5])

#####

N = X.shape[0]
input_dim = X.shape[1]  # D
# M1: number of neurons in the encoder
# M2: number of neurons in the decoder
hidden_encoder_dim = 400  # M1
hidden_decoder_dim = hidden_encoder_dim  # M2
latent_dim = int(sys.argv[1])  # Z_dim
epochs = int(sys.argv[2])
batch_size = sys.argv[3]
if batch_size == 'N':
    batch_size = X.shape[0]
else:
    batch_size = int(batch_size)
learning_rate = float(sys.argv[4])

#####

# plot X
fig = plot_data.plot_browse_dataset(X, y, title='Original Data')
fig.savefig(output_images_dir + '/original_data.png', bbox_inches='tight')
plt.close()

# plot X_missing
fig = plot_data.plot_browse_dataset(X_missing, y, title='Missing Data')
fig.savefig(output_images_dir + '/missing_data.png', bbox_inches='tight')
plt.close()

#####

params, solver = initialize_weights_in_pytorch.initialize_weights(input_dim, hidden_encoder_dim, hidden_decoder_dim, latent_dim, lr=learning_rate)

cur_samples = None
batch_labels = None
cur_elbo = None
masked_batch_data = None

# X_test_masked: array with 0s where the pixels are missing
# and 1s where the pixels are not missing
X_masked = np.array(X_missing)
X_masked[np.where(X_masked != missing_value)] = 1
X_masked[np.where(X_masked == missing_value)] = 0

non_zero_percentage = Utilities.non_zero_percentage(X_masked)
print('non missing values percentage: ' + str(non_zero_percentage) + ' %')

X_filled = np.array(X_missing)

print('')

start_time = time.time()
for epoch in range(1, epochs + 1):
    iterations = int(N / batch_size)
    for i in range(iterations):
        start_index = i * batch_size
        end_index = (i + 1) * batch_size

        batch_data = X_filled[start_index:end_index, :]
        batch_labels = y[start_index:end_index]

        cur_samples, cur_elbo = vae_in_pytorch.train(batch_data, batch_size, latent_dim, params, solver)

        masked_batch_data = X_masked[start_index:end_index, :]
        cur_samples = np.multiply(masked_batch_data, batch_data) + np.multiply(1 - masked_batch_data, cur_samples)
        X_filled[start_index:end_index, :] = cur_samples

    print('Epoch {0} | Loss (ELBO): {1}'.format(epoch, cur_elbo))

    if epoch == 1:

        fig = plot_data.plot_browse_dataset(masked_batch_data, batch_labels, title='Masked Data')
        fig.savefig(output_images_dir + '/masked_data.png', bbox_inches='tight')
        plt.close()

    if epoch % 10 == 0 or epoch == 1:

        fig = plot_data.plot_browse_dataset(cur_samples, batch_labels, title='Epoch {}'.format(str(epoch).zfill(3)))
        fig.savefig(output_images_dir + '/epoch_{}.png'.format(str(epoch).zfill(3)), bbox_inches='tight')
        plt.close()

print('')
elapsed_time = time.time() - start_time

print('training time: ' + str(elapsed_time))
print('')

error1 = Utilities.rmse(X, X_filled)
print('root mean squared error: ' + str(error1))

error2 = Utilities.mae(X, X_filled)
print('mean absolute error: ' + str(error2))
