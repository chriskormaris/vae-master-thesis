import numpy as np
from pandas import DataFrame
import pandas as pd

# set options
pd.set_option('display.width', 1000)
pd.set_option('display.max_rows', 200)


###############


def get_browse_dataset(dataset_file):
    print('Reading dataset...')

    df = pd.read_csv(dataset_file, delimiter=' ', header=None)
    X = df.values

    X = X.astype(np.float)

    return X


def get_browse_dataset_labels(dataset_labels_file):
    print('Reading dataset labels...')

    with open(dataset_labels_file) as f:
        y = np.array(f.readlines())

    return y.astype(np.int8)


###############

# MAIN #

if __name__ == '__main__':

    dir_path = '../../../Binarized_MNIST_dataset'

    # read MNIST data
    X_train = get_browse_dataset(dir_path + '/binarized_mnist_train.amat')
    # X_train = np.reshape(X_train, newshape=(X_train.shape[0], int(np.sqrt(X_train.shape[1])), int(np.sqrt(X_train.shape[1]))))
    print('')
    X_test = get_browse_dataset(dir_path + '/binarized_mnist_test.amat')
    # X_test = np.reshape(X_test, newshape=(X_test.shape[0], int(np.sqrt(X_test.shape[1])), int(np.sqrt(X_test.shape[1]))))
    print('')
    X_valid = get_browse_dataset(dir_path + '/binarized_mnist_valid.amat')
    # X_valid = np.reshape(X_valid, newshape=(X_valid.shape[0], int(np.sqrt(X_valid.shape[1])), int(np.sqrt(X_valid.shape[1]))))
    print('')

    print('')

    print('X_train:')
    df = DataFrame(X_train)
    df.index = range(X_train.shape[0])
    df.columns = range(X_train.shape[1])
    print(df)

    print('')

    print('X_test:')
    df = DataFrame(X_test)
    df.index = range(X_test.shape[0])
    df.columns = range(X_test.shape[1])
    print(df)

    print('')

    print('X_val:')
    df = DataFrame(X_valid)
    df.index = range(X_valid.shape[0])
    df.columns = range(X_valid.shape[1])
    print(df)

    print('')

    # read MNIST labels
    y_test = get_browse_dataset_labels(dir_path + '/binarized_mnist_test_labels.txt', 'test')

    print('y_test: ' + str(y_test))
    print('y_test shape: ' + str(y_test.shape))
